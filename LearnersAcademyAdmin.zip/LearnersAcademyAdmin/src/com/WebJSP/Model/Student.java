package com.WebJSP.Model;

public class Student {

	int studentid;
	String studentname;
	String emailid;
	String phonenbr;
	String classname;
	
	
	public Student() {
		super();
		// TODO Auto-generated constructor stub
	}


	public Student(int studentid, String studentname, String emailid, String phonenbr, String classname) {
		super();
		this.studentid = studentid;
		this.studentname = studentname;
		this.emailid = emailid;
		this.phonenbr = phonenbr;
		this.classname = classname;
	}


	public Student(String studentname, String emailid, String phonenbr, String classname) {
		super();
		this.studentname = studentname;
		this.emailid = emailid;
		this.phonenbr = phonenbr;
		this.classname = classname;
	}


	public int getStudentid() {
		return studentid;
	}


	public void setStudentid(int studentid) {
		this.studentid = studentid;
	}


	public String getStudentname() {
		return studentname;
	}


	public void setStudentname(String studentname) {
		this.studentname = studentname;
	}


	public String getEmailid() {
		return emailid;
	}


	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}


	public String getPhonenbr() {
		return phonenbr;
	}


	public void setPhonenbr(String phonenbr) {
		this.phonenbr = phonenbr;
	}


	public String getClassname() {
		return classname;
	}


	public void setClassname(String classname) {
		this.classname = classname;
	}
	
	
	
}
