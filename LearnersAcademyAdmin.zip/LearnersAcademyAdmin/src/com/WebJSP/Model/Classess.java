package com.WebJSP.Model;

public class Classess {
	
	int classid;
	String classname;
	
	public Classess() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public Classess(int classid, String classname) {
		super();
		this.classid = classid;
		this.classname = classname;
	}

	public Classess(String classname) {
		super();
		this.classname = classname;
	}

	public int getClassid() {
		return classid;
	}

	public void setClassid(int classid) {
		this.classid = classid;
	}

	public String getClassname() {
		return classname;
	}

	public void setClassname(String classname) {
		this.classname = classname;
	}
	
		

}
