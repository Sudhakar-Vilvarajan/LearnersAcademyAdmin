package com.WebJSP.Model;

public class Subject {
	
	int subjectcode;
	String subjectname;
	public Subject() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Subject(int subjectcode, String subjectname) {
		super();
		this.subjectcode = subjectcode;
		this.subjectname = subjectname;
	}
	public Subject(String subjectname) {
		super();
		this.subjectname = subjectname;
	}
	public int getsubjectcode() {
		return subjectcode;
	}
	public void setsubjectcode(int subjectcode) {
		this.subjectcode = subjectcode;
	}
	public String getsubjectname() {
		return subjectname;
	}
	public void setsubjectname(String subjectname) {
		this.subjectname = subjectname;
	}


	

}
