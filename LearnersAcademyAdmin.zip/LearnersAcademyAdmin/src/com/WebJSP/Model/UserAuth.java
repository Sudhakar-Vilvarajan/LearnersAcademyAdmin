package com.WebJSP.Model;

public class UserAuth {

	String username;
	String userpwd;
	
	public UserAuth() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public UserAuth(String username, String userpwd) {
		super();
		this.username = username;
		this.userpwd = userpwd;
	}
	
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getUserpwd() {
		return userpwd;
	}
	public void setUserpwd(String userpwd) {
		this.userpwd = userpwd;
	}
	
	
	
}
