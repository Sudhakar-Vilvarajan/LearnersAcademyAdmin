package com.WebJSP.dao;

import com.WebJSP.Model.*;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UserDAO {
	
	
	//private String jdbcURL = "jdbc:mysql://localhost:3306/testdb?useSSL=false";
	
	private String jdbcURL = "jdbc:mysql://localhost:3306/StudentDB?useSSL=false";
	

	private String jdbcUsername = "root";
	private String jdbcPassword = "password";

	private static final String INSERT_USERS_SQL = "INSERT INTO users" + "  (name, email, country) VALUES " + " (?, ?, ?);";

	private static final String SELECT_USER_BY_ID = "select id,name,email,country from users where id =?";
	private static final String SELECT_ALL_USERS = "select * from users";
	private static final String DELETE_USERS_SQL = "delete from users where id = ?;";
	private static final String UPDATE_USERS_SQL = "update users set name = ?,email= ?, country =? where id = ?";

	public UserDAO() {
	}

	protected Connection getConnection() {
		Connection connection = null;
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			connection = DriverManager.getConnection(jdbcURL, jdbcUsername, jdbcPassword);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return connection;
	}

	private void printSQLException(SQLException ex) {
		for (Throwable e : ex) {
			if (e instanceof SQLException) {
				e.printStackTrace(System.err);
				System.err.println("SQLState: " + ((SQLException) e).getSQLState());
				System.err.println("Error Code: " + ((SQLException) e).getErrorCode());
				System.err.println("Message: " + e.getMessage());
				Throwable t = ex.getCause();
				while (t != null) {
					System.out.println("Cause: " + t);
					t = t.getCause();
				}
			}
		}
	}

	public void insertUser(User user) throws SQLException {
		System.out.println(INSERT_USERS_SQL);
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement(INSERT_USERS_SQL)) {
			preparedStatement.setString(1, user.getName());
			preparedStatement.setString(2, user.getEmail());
			preparedStatement.setString(3, user.getCountry());
			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
	}

	public User selectUser(int id) {
		User user = null;
		// Step 1: Establishing a Connection
		try (Connection connection = getConnection();
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_ID);) {
			preparedStatement.setInt(1, id);
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			
			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				String name = rs.getString("name");
				String email = rs.getString("email");
				String country = rs.getString("country");
				user = new User(id, name, email, country);
			}
			
		} catch (SQLException e) {
			printSQLException(e);
		}
		System.out.println(user);
		return user;
	}

	public List<User> selectAllUsers() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<User> users = new ArrayList<>();
		// Step 1: Establishing a Connection
		//System.out.println("Test1\n");
		try (Connection connection = getConnection();

				
				// Step 2:Create a statement using connection object
				PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ALL_USERS);) {
				//PreparedStatement preparedStatement = connection.prepareStatement();) {
			//System.out.println("Test2\n");
			
			System.out.println(preparedStatement);
			// Step 3: Execute the query or update query
			ResultSet rs = preparedStatement.executeQuery();
			//System.out.println(rs.getFetchSize());
			//System.out.println("Test3\n");
			// Step 4: Process the ResultSet object.
			while (rs.next()) {
				int id = rs.getInt("id");
				String name = rs.getString("name");
				String email = rs.getString("email");
				String country = rs.getString("country");
				users.add(new User(id, name, email, country));
				//System.out.println(name);
			}
			//System.out.println("Test4\n");
		} catch (SQLException e) {
			//System.out.println("Test5\n");
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteUser(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(DELETE_USERS_SQL);) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}

	public boolean updateUser(User user) throws SQLException {
		boolean rowUpdated;
		System.out.println(user.getEmail());
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement(UPDATE_USERS_SQL);) {
			System.out.println(statement);
			statement.setString(1, user.getName());
			statement.setString(2, user.getEmail());
			statement.setString(3, user.getCountry());
			statement.setInt(4, user.getId());
			System.out.println(statement);
			rowUpdated = statement.executeUpdate() > 0;
		}
		return rowUpdated;
	}

	
	public boolean CheckUserAuthentication(String Userid, String pwd) throws SQLException {
		boolean isUserValid;
		
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("select * from admin where UserID =  ? and Pwd = ?;");) {
				//PreparedStatement statement = connection.prepareStatement("select * from users;");) {
			statement.setString(1, Userid);
			statement.setString(2, pwd);
			System.out.println(statement + "\n");
			ResultSet rs = statement.executeQuery();
			rs.next();
			if (rs.getRow() > 0)
				isUserValid = true;
			else
				isUserValid = false;
			
		}
		return isUserValid;
	}
	
	public Boolean insertAdminUser(UserAuth user) throws SQLException {
		Boolean userExist = false;
		// try-with-resource statement will auto close the connection.
		try (Connection connection = getConnection();
		PreparedStatement statement = connection.prepareStatement("select * from admin where UserID =  ?;");) {
		statement.setString(1, user.getUsername());
		System.out.println(statement + "\n");
		ResultSet rs = statement.executeQuery();
		rs.next();
			if (rs.getRow() > 0)
				{
				System.out.println("User Already Exist");
				userExist = true;
				}
			else
				{
					userExist = false;
					PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO admin" + "  (UserID, Pwd) VALUES " + " (?, ?);");
					preparedStatement.setString(1, user.getUsername());
					preparedStatement.setString(2, user.getUserpwd());
					System.out.println(preparedStatement);
					preparedStatement.executeUpdate();
					userExist = false;
				}
		
		} catch (SQLException e) {
			printSQLException(e);
		}
		return userExist;
	}
	
	public Boolean insertNewClass(Classess user) throws SQLException {
		
		Boolean classExist = false;

		try (Connection connection = getConnection();
				PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO class" + "  (ClassName) VALUES " + " (?);")) {
			preparedStatement.setString(1, user.getClassname());

			System.out.println(preparedStatement);
			preparedStatement.executeUpdate();
		} catch (SQLException e) {
			printSQLException(e);
		}
		return classExist;
	}

	
	public List<Classess> selectAllClasses() {

		// using try-with-resources to avoid closing resources (boiler plate code)
		List<Classess> users = new ArrayList<>();
		try (Connection connection = getConnection();

				PreparedStatement preparedStatement = connection.prepareStatement("Select * From Class;")) {
			
			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				int id = rs.getInt("ClassID");
				String name = rs.getString("ClassName");
				users.add(new Classess(id, name));
			}
		} catch (SQLException e) {
			printSQLException(e);
		}
		return users;
	}

	public boolean deleteClass(int id) throws SQLException {
		boolean rowDeleted;
		try (Connection connection = getConnection();
				PreparedStatement statement = connection.prepareStatement("Delete from Class where ClassID =  ?;");) {
			statement.setInt(1, id);
			rowDeleted = statement.executeUpdate() > 0;
		}
		return rowDeleted;
	}



public List<Subject> selectAllSubjects() {

	// using try-with-resources to avoid closing resources (boiler plate code)
	List<Subject> objSubject = new ArrayList<>();
	try (Connection connection = getConnection();

			PreparedStatement preparedStatement = connection.prepareStatement("Select * From Subject;")) {
		
		System.out.println(preparedStatement);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			int id = rs.getInt("SubjectCode");
			String name = rs.getString("SubjectName");
			objSubject.add(new Subject(id, name));
			//System.out.println(id + "  " + name);
		}
	} catch (SQLException e) {
		printSQLException(e);
	}
	return objSubject;
}


public Boolean insertNewSubject(Subject objSubject) throws SQLException {
	
	Boolean subjectExist = false;

	try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Subject" + "  (SubjectName) VALUES " + " (?);")) {
		preparedStatement.setString(1, objSubject.getsubjectname());

		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();
	} catch (SQLException e) {
		printSQLException(e);
	}
	return subjectExist;
}

public boolean deleteSubject(int id) throws SQLException {
	boolean rowDeleted;
	try (Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement("Delete from Subject where SubjectCode =  ?;");) {
		statement.setInt(1, id);
		rowDeleted = statement.executeUpdate() > 0;
	}
	return rowDeleted;
}

public List<Teacher> selectAllTeachers() {

	// using try-with-resources to avoid closing resources (boiler plate code)
	List<Teacher> objTeacher = new ArrayList<>();
	try (Connection connection = getConnection();

			PreparedStatement preparedStatement = connection.prepareStatement("Select * From Teacher;")) {
		
		System.out.println(preparedStatement);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			int id = rs.getInt("TeacherID");
			String name = rs.getString("TeacherName");
			String sname = rs.getString("SubjectName");
			objTeacher.add(new Teacher(id, name,sname));
			System.out.println(id + "  " + name);
		}
	} catch (SQLException e) {
		printSQLException(e);
	}
	return objTeacher;
}

public Boolean insertNewTeacher(Teacher objTeacher) throws SQLException {
	
	Boolean subjectExist = false;

	try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Teacher" + "  (TeacherName,SubjectName) VALUES " + " (?,?);")) {
		preparedStatement.setString(1, objTeacher.getTeachername());
		preparedStatement.setString(2, objTeacher.getSubjectname());

		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();
	} catch (SQLException e) {
		printSQLException(e);
	}
	return subjectExist;
}

public boolean deleteTeacher(int id) throws SQLException {
	boolean rowDeleted;
	try (Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement("Delete from Teacher where TeacherID =  ?;");) {
		statement.setInt(1, id);
		rowDeleted = statement.executeUpdate() > 0;
	}
	return rowDeleted;
}

public List<Student> selectAllStudents() {
	// TODO Auto-generated method stub
	// using try-with-resources to avoid closing resources (boiler plate code)
	List<Student> objStudent = new ArrayList<>();
	try (Connection connection = getConnection();

			PreparedStatement preparedStatement = connection.prepareStatement("Select * From Student;")) {
		
		System.out.println(preparedStatement);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			int id = rs.getInt("StudentID");
			String name = rs.getString("StudentName");
			String emailadr = rs.getString("Email");
			String phonenbr = rs.getString("PhoneNo");
			String classname = rs.getString("ClassName");
			
			objStudent.add(new Student(id, name,emailadr,phonenbr,classname));
		}
	} catch (SQLException e) {
		printSQLException(e);
	}
	return objStudent;
}

public Boolean insertNewStudent(Student newStudent) {

	Boolean subjectExist = false;

	try (Connection connection = getConnection();
			PreparedStatement preparedStatement = connection.prepareStatement("INSERT INTO Student" + "  (StudentName,Email,PhoneNo,ClassName) VALUES " + " (?,?,?,?);")) {
		preparedStatement.setString(1, newStudent.getStudentname());
		preparedStatement.setString(2, newStudent.getEmailid());
		preparedStatement.setString(3, newStudent.getPhonenbr());
		preparedStatement.setString(4, newStudent.getClassname());

		System.out.println(preparedStatement);
		preparedStatement.executeUpdate();
	} catch (SQLException e) {
		printSQLException(e);
	}
	return subjectExist;
	
}

public boolean deleteStudent(int id) throws SQLException {
	boolean rowDeleted;
	try (Connection connection = getConnection();
			PreparedStatement statement = connection.prepareStatement("Delete from Student where StudentID =  ?;");) {
		statement.setInt(1, id);
		rowDeleted = statement.executeUpdate() > 0;
	}
	return rowDeleted;
}


}