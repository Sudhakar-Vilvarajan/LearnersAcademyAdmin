package com.WebJSP.Web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession(true);
		if(session != null) {
			 writer.println("Session Exists..");
			 writer.println("Session Id : " + session.getId());
			// session.removeAttribute("username");
			// session.invalidate();
			// request.getRequestDispatcher("login.html").include(request, response);
			// writer.println("<h3>You are successfully logged out.</h3>");
		} else {
			writer.println("Session doesn't Exist.");
		}
	}

}
